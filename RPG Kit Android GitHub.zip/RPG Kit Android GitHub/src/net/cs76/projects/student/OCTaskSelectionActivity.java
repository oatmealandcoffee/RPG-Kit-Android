/**
 * Philip Regan
 * http://www.oatmealandcoffee.com
 * 
 * 
 * OCTaskSelectionActivity
 * 
 * Activity for selecting a task for a variety of reasons
 * 
 */
package net.cs76.projects.student;

/**
 * @author philipr
 *
 */
public class OCTaskSelectionActivity extends OCGameObjectSelectionActivity {

	/**
	 * Auto-generated constructor stub
	 */
	public OCTaskSelectionActivity() {
		// Auto-generated constructor stub
	}

}
