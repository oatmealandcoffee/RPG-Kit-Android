/**
 * Philip Regan
 * http://www.oatmealandcoffee.com
 * 
 * 
 * OCEquipmentSelectionActivity
 * 
 * Activity for selecting an equipment object for a variety of reasons
 * 
 */
package net.cs76.projects.student;

/**
 * @author philipr
 *
 */
public class OCEquipmentSelectionActivity extends OCGameObjectSelectionActivity {

	/**
	 * Auto-generated constructor stub
	 */
	public OCEquipmentSelectionActivity() {
		// Auto-generated constructor stub
	}

}
